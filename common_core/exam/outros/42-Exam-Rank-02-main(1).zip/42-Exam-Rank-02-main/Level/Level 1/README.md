----
## Table of 12 Assignment
- [Level 1](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/)
	+ [first_word](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/first_word)
	+ [fizzbuzz](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/fizzbuzz)
	+ [ft_strlen](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/ft_strlen)
	+ [ft_swap](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/ft_swap)
	+ [putstr](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/putstr)
	+ [repeat_alpha](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/repeat_alpha)
	+ [rev_print](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/rev_print)
	+ [rot_13](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/rot_13)
	+ [rotone](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/rotone)
	+ [search_and_replace](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/search_and_replace)
	+ [ulstr](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%201/ulstr)
----
