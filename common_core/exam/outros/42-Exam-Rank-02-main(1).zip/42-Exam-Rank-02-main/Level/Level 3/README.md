----
## Table of 15 Assignment
- [Level 3](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/)
	+ [add_prime_sum](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/add_prime_sum)
	+ [epur_str](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/epur_str)
	+ [expand_str](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/expand_str)
	+ [ft_atoi_base](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/ft_atoi_base)
	+ [ft_list_size](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/ft_list_size)
	+ [ft_range](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/ft_range)
	+ [hidenp](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/hidenp)
	+ [lcm](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/lcm)
	+ [paramsum](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/paramsum)
	+ [pgcd](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/pgcd)
	+ [print_hex](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/print_hex)
	+ [rstr_capitalizer](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/rstr_capitalizer)
	+ [str_capitalizer](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/str_capitalizer)
	+ [tab_mult](https://github.com/ComlanGiovanni/42-Exam-Rank-02/tree/main/Level/Level%203/tab_mult)
----
