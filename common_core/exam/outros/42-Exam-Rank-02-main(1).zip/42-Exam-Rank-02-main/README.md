<img align="left" width="100" height="169" src="42_logo.png">

		- The exam has 4 random question picked from each level.
		- You need to validate the 4 question to get 100.
		- Each time you fail the exam you restart at level 1.
		- There is no Norminette in the exam.
		- All the solution of the repo are normed(v3).
		- 56 Assigment in total, all main in train.c of each one.

 ![main test](https://badgen.net/badge/main/Main-Test/red?icon=github&label)
 ![norminette](https://badgen.net/badge/Norminette/42-Norminette-v3-Passed/green?icon=github&label)
 ![clean code](https://badgen.net/badge/Readable&Clean-Code/Readable&Clean-Code/blue?icon=github&label)
 [![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FComlanGiovanni%2F42-Exam-Rank-02&count_bg=%237F827C&title_bg=%23555555&icon=datacamp.svg&icon_color=%23C8BCBC&title=views&edge_flat=false)](https://hits.seeyoufarm.com)

```
	/* ************************************************************************** */
	/*                                                                            */
	/*                                                        :::      ::::::::   */
	/*   42_Exam_Rank_02.c  (Version -> 2024)               :+:      :+:    :+:   */
	/*                                                    +:+ +:+         +:+     */
	/*   By: gicomlan <gicomlan@student.42.fr>          +#+  +:+       +#+        */
	/*                                                +#+#+#+#+#+   +#+           */
	/*   Created: 1999/01/01 23:59:59 by gicomlan          #+#    #+#             */
	/*   Updated: 1900/01/01 00:00:01 by gicomlan         ###   ########.fr       */
	/*                                                                            */
	/* ************************************************************************** */
```

<details>
<summary>Good luck 💚</summary>

```
Any fool can write code that a computer can understand.
Good programmers write code that humans can understand,
so if you want to go fast, if you want to get done quickly,
if you want your code to be easy to write, make it easy to read.

Martin Fowler && Robert C. Martin
```

</details>


<div align='right'>

[![gcomlan's 42 Exam Rank 02 Score](https://badge42.vercel.app/api/v2/cl4d7ypa5004009l93h57346v/project/2726502)](https://github.com/JaeSeoKim/badge42)

[@gcomlan](https://profile.intra.42.fr/users/gcomlan)

</div>
