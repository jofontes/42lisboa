Exam Rank 2 =>  [ft_printf](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/) | | [get_next_line](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/get_next_line/)

<img align="left" width="100" height="169" src="42_logo.png">

		- The exam has 1 question picked between 2 !
		- You need to validate 1 question to get 100.
		- Each time you fail the exam you restart.
		- There is no Norminette in the exam.
		- All the solution of the repo are normed(v3) not gnl.....
		- If someone can norm the main gnl and keep it clean code PR the code.
		- 2 Assigment, all main in train.c of each one.

![main test](https://badgen.net/badge/main/Main-Test/red?icon=github&label)
![norminette](https://badgen.net/badge/Norminette/42-Norminette-v3-Passed/green?icon=github&label)
![clean code](https://badgen.net/badge/Readable&Clean-Code/Readable&Clean-Code/blue?icon=github&label)
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FComlanGiovanni%2F42-Exam-Rank-03&count_bg=%23BCC4B6&title_bg=%23A09898&icon=datacamp.svg&icon_color=%23FFFFFF&title=Views&edge_flat=false)](https://hits.seeyoufarm.com)

```
	/* ************************************************************************** */
	/*                                                                            */
	/*                                                        :::      ::::::::   */
	/*   42_Exam_Rank_03.c  (Version -> 2024)               :+:      :+:    :+:   */
	/*                                                    +:+ +:+         +:+     */
	/*   By: gcomlan <gicomlan@student.42.fr>           +#+  +:+       +#+        */
	/*                                                +#+#+#+#+#+   +#+           */
	/*   Created: 1999/01/01 23:59:59 by gicomlan          #+#    #+#             */
	/*   Updated: 1900/01/01 00:00:01 by gicomlan         ###   ########.fr       */
	/*                                                                            */
	/* ************************************************************************** */
```

<details>
<summary>Good luck 💚</summary>

```
Any fool can write code that a computer can understand.
Good programmers write code that humans can understand,
so if you want to go fast, if you want to get done quickly,
if you want your code to be easy to write, make it easy to read.

Martin Fowler && Robert C. Martin
```

</details>
