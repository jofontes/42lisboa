<div><a href="https://grademe.fr/#"> WARNING !!!! I Did not test all the version please test before using those or use the primary one || try to fix it</a></div>

## Short Version
- [Back](https://github.com/ComlanGiovanni/42-Exam-Rank-03/tree/main/ft_printf)
	+ [short_0.c](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/short-version/short_0.c)
	+ [short_1.c](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/short-version/short_1.c)
	+ [short_2.c](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/short-version/short_2.c)
	+ [short_3.c](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/short-version/short_3.c)

<a href="https://imgflip.com/i/6qu7jl"><img src="https://i.imgflip.com/6qu7jl.jpg" title="made at imgflip.com"/></a>
