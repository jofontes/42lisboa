Exam Rank 4 =>  [microshell.c](https://github.com/ComlanGiovanni/42-Exam-Rank-03/blob/main/ft_printf/)

<img align="left" width="100" height="169" src="42_logo.png">

		- The exam has 1 question !
		- You need to validate 1 question to get 100.
		- Each time you fail the exam you restart.
		- There is no Norminette in the exam.
		- All the solution of the repo are normed(v3).
		- 1 Assigment.

![main test](https://badgen.net/badge/main/Main-Test/red?icon=github&label)
![norminette](https://badgen.net/badge/Norminette/42-Norminette-v3-Passed/green?icon=github&label)
![clean code](https://badgen.net/badge/Readable&Clean-Code/Readable&Clean-Code/blue?icon=github&label)

```
	/* ************************************************************************** */
	/*                                                                            */
	/*                                                        :::      ::::::::   */
	/*   42_Exam_Rank_04.c  (Version -> 2022)               :+:      :+:    :+:   */
	/*                                                    +:+ +:+         +:+     */
	/*   By: gcomlan <gcomlan@student.42.fr>            +#+  +:+       +#+        */
	/*                                                +#+#+#+#+#+   +#+           */
	/*   Created: 1999/01/01 23:59:59 by gcomlan           #+#    #+#             */
	/*   Updated: 1900/01/01 00:00:01 by gcomlan          ###   ########.fr       */
	/*                                                                            */
	/* ************************************************************************** */
```

<details>
<summary>Good luck 💚</summary>

```
Any fool can write code that a computer can understand.
Good programmers write code that humans can understand,
so if you want to go fast, if you want to get done quickly,
if you want your code to be easy to write, make it easy to read.

Martin Fowler && Robert C. Martin
```

</details>
